# Game Buddy 0.7 — prévia

Um buddy que mora na sua tela e reage às suas partidas. Funciona sozinho, sem Overwolf.

## Novidades

- **Rocket League sem Overwolf:** gol, gol sofrido, bola na trave e resultado chegam sozinhos pela conexão oficial do jogo.
- **Três buddies premium novos:** Kitsu, Nimbo e Marina, cada um com suas falas. Junto com o Drako, estão liberados em prévia, sem cobrança.
- **Tela cheia:** quando o jogo deixa, o buddy volta pra frente dele sozinho.

## Abrir

1. Extraia a pasta inteira do ZIP. Não abra o app de dentro do ZIP.
2. Abra o `GameBuddy.exe`. Se aparecer "O Windows protegeu o computador", clique em **Mais informações → Executar assim mesmo**, porque o app ainda não tem assinatura digital.
3. Escolha um buddy e clique em **Colocar buddy na tela**.

Precisa de Windows 10 ou 11. Não instala nada, não pede administrador e não manda nada pra internet.

## Testar no CS2

No CS2 ainda não tem reação automática. O teste é ver se o buddy aparece por cima do jogo.

1. Com o buddy na tela, abra o CS2 e entre numa partida (pode ser contra bots).
2. Teste no modo **Tela cheia** e depois em **Janela em tela cheia** (Configurações → Vídeo → Modo de exibição).
3. Durante a partida, aperte **Ctrl + Alt + V** e o buddy comemora uma vitória por cima do jogo.
4. Conta pra gente: ele apareceu em cada modo? O jogo travou, piscou ou perdeu FPS?

O Game Buddy não mexe no jogo nem injeta nada nele, então não tem risco de VAC.

## Rocket League

Clique em **Rocket League · reações automáticas → Ativar no Rocket League**, depois feche e abra o jogo. Na tela cheia exclusiva do Rocket League o Windows esconde o buddy, então use **Janela sem bordas**.

## Atalhos

- **Ctrl + Alt + B:** mostra ou esconde o buddy.
- **Ctrl + Alt + V:** testa uma vitória.
