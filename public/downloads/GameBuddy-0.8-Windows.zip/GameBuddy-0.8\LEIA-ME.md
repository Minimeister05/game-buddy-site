# Game Buddy 0.8 — prévia

Um buddy que mora na sua tela e reage às suas partidas. Funciona sozinho, sem Overwolf.

## Novidades

- **CS2:** abate, morte, round ganho ou perdido e resultado da partida chegam sozinhos pela integração oficial da Valve.
- **Minecraft Java:** o buddy comemora suas conquistas e sofre com suas mortes. Funciona com o launcher oficial, CurseForge, Prism e Modrinth, sem instalar mod.
- **Rocket League:** gol, gol sofrido, bola na trave e resultado pela conexão oficial do jogo.
- **Sete buddies:** Astro, Mochi e Bolt, mais os premium Drako, Kitsu, Nimbo e Marina, liberados em prévia sem cobrança.

## Abrir

1. Extraia a pasta inteira do ZIP. Não abra o app de dentro do ZIP.
2. Abra o `GameBuddy.exe`. Se aparecer "O Windows protegeu o computador", clique em **Mais informações → Executar assim mesmo**, porque o app ainda não tem assinatura digital.
3. Escolha um buddy e clique em **Colocar buddy na tela**.

Precisa de Windows 10 ou 11. Não instala nada, não pede administrador e não manda nada pra internet.

## Ligar as reações automáticas

Clique em **Reações automáticas nos jogos**:

- **CS2:** clique em **Ativar no CS2** e depois feche e abra o jogo. Jogue em **Janela preenchida**, porque em Tela cheia o Windows esconde o buddy.
- **Rocket League:** clique em **Ativar no Rocket League** e depois feche e abra o jogo. Use **Janela sem bordas**.
- **Minecraft Java:** não precisa fazer nada, é só jogar.

O Game Buddy não mexe no jogo nem injeta nada nele, então não tem risco de ban nem de VAC.

## Atalhos

- **Ctrl + Alt + B:** mostra ou esconde o buddy.
- **Ctrl + Alt + V:** testa uma vitória.
